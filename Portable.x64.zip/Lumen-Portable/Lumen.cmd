@echo off
setlocal
set "LUMEN_DATA_DIR=%~dp0profile"
start "" "%~dp0lumen.exe"
