@echo off
setlocal
set "LUMEN_DATA_DIR=%~dp0profile-data"
start "" "%~dp0lumen.exe" %*
